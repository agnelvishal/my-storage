Installation Guide
===========================

1. npm install
2. node app.js


Description
===========================

1. The index.html has the frontend for testing purpose and for manually sending the cryptocurrency. It has the api calls.
2. The sendRydeToken.js has the code for sending the crypto from wallet to wallet. The contract ABI is also present there.
3. The API call for sending crypto from wallet to wallet is at https://gist.github.com/agnelvishal/51220774885092a4e54827b13a551711 Do not forget to add the Wallet address and Private key. You can copy paste api call code in the mobile app. It will send the crypto from rider to operator, driver and Rydeum.
4. The gen.js has the code for generating address and privatekey 
5. The API call for generating address and privatekey is at https://gist.github.com/agnelvishal/e3b0f4f3d22d9efa1426cf05521bc860  You can copy paste the api call code in the mobile app to get the address and privatekey. You will need to store the address and private key in the database
6. To get the price of 1 Ryde token in USDC, the priceAPI.js has been used. The sample API call is at https://gist.github.com/agnelvishal/25d74b9b7d43e86d8b40a518f2a619d1

