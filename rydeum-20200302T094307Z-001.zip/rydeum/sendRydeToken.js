const Web3 = require('web3')

const Tx = require('ethereumjs-tx').Transaction

const Web3js = new Web3('https://ropsten.infura.io/v3/6c788638f2d446a6be19c68b275a29a5')

let tokenAddress = '0xe0957c7d7d0a8da56a0df7b4fc17a3c78638ec4e' // Rydeum contract address



let contractABI = [{
  "constant": true, "inputs": [], "name": "name", "outputs": [{ "name": "", "type": "string" }],
  "payable": false, "stateMutability": "view", "type": "function"
}, {
  "constant": true, "inputs": [], "name": "totalSupply", "outputs": [{ "name": "", "type": "uint256" }],
  "payable": false, "stateMutability": "view", "type": "function"
}, {
  "constant": true, "inputs": [], "name": "decimals", "outputs": [{ "name": "", "type": "uint256" }],
  "payable": false, "stateMutability": "view", "type": "function"
}, {
  "constant": true, "inputs": [], "name": "MAX_UINT256", "outputs": [{
    "name": "",
    "type": "uint256"
  }], "payable": false, "stateMutability": "view", "type": "function"
},
{
  "constant": false, "inputs": [{ "name": "_value", "type": "uint256" }], "name": "burn", "outputs": [{ "name": "", "type": "bool" }],
  "payable": false, "stateMutability": "nonpayable", "type": "function"
}, {
  "constant": true, "inputs": [], "name": "mintable", "outputs": [{ "name": "", "type": "bool" }],
  "payable": false, "stateMutability": "view", "type": "function"
}, {
  "constant": true, "inputs": [{ "name": "_owner", "type": "address" }],
  "name": "balanceOf", "outputs": [{ "name": "balance", "type": "uint256" }], "payable": false, "stateMutability": "view", "type": "function"
},
{ "constant": true, "inputs": [], "name": "owner", "outputs": [{ "name": "", "type": "address" }], "payable": false, "stateMutability": "view", "type": "function" },
{ "constant": true, "inputs": [], "name": "symbol", "outputs": [{ "name": "", "type": "string" }], "payable": false, "stateMutability": "view", "type": "function" },
{ "constant": false, "inputs": [{ "name": "amount", "type": "uint256" }], "name": "mint", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" },
{ "constant": false, "inputs": [{ "name": "_to", "type": "address" }, { "name": "_value", "type": "uint256" }], "name": "transfer", "outputs": [{ "name": "success", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "name": "_to", "type": "address" }, { "name": "_value", "type": "uint256" }, { "name": "_data", "type": "bytes" }], "name": "transfer", "outputs": [{ "name": "success", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "name": "newOwner", "type": "address" }], "name": "transferOwnership", "outputs": [], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "constant": false, "inputs": [{ "name": "_to", "type": "address" }, { "name": "_value", "type": "uint256" }, { "name": "_data", "type": "bytes" }, { "name": "_custom_fallback", "type": "string" }], "name": "transfer", "outputs": [{ "name": "success", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "function" }, { "inputs": [{ "name": "_owner", "type": "address" }, { "name": "_name", "type": "string" }, { "name": "_symbol", "type": "string" }, { "name": "_decimals", "type": "uint256" }, { "name": "_totalSupply", "type": "uint256" }, { "name": "_mintable", "type": "bool" }], "payable": false, "stateMutability": "nonpayable", "type": "constructor" }, { "anonymous": false, "inputs": [{ "indexed": true, "name": "from", "type": "address" }, { "indexed": true, "name": "to", "type": "address" }, { "indexed": false, "name": "value", "type": "uint256" }], "name": "Transfer", "type": "event" }, {
  "anonymous": false, "inputs": [{ "indexed": true, "name": "from", "type": "address" }, { "indexed": true, "name": "to", "type": "address" },
  { "indexed": false, "name": "value", "type": "uint256" }, { "indexed": false, "name": "data", "type": "bytes" }], "name": "Transfer", "type": "event"
}]


async function sendRydeToken(amountG, toAddressG, fromAddressG, privateKeyG) {

  try {


    let fromAddress = fromAddressG // The rider wallet address from where the cryptotoken is sent.
    let privateKey = Buffer.from(privateKeyG, 'hex') // The privatekey of the rider wallet address.

    let contract = new Web3js.eth.Contract(contractABI, tokenAddress, { from: fromAddress })

    //let toAddress = '0x4c93a5590d6372af3e1c9be3954c39c590e60038' // where to send it  
    let toAddress = toAddressG

    // 1e18 === 1 Rydeum Token
    let amount = Web3js.utils.toHex(amountG * 1e18)
    count = await Web3js.eth.getTransactionCount(fromAddress)

    let rawTransaction = {
      'from': fromAddress,
      'gasPrice': Web3js.utils.toHex(2000 * 1e9),
      'gasLimit': Web3js.utils.toHex(220000),
      'to': tokenAddress,
      'value': 0x0,
      'data': contract.methods.transfer(toAddress, amount).encodeABI(),
      'nonce': Web3js.utils.toHex(count)
    }
    let transaction = new Tx(rawTransaction, { chain: 'ropsten', hardfork: 'petersburg' })
    transaction.sign(privateKey)
    const Thash = Web3js.eth.sendSignedTransaction('0x' + transaction.serialize().toString('hex'))
    return Thash;
  }
  catch (err) {
    console.log("AV:sendRydeToken:");
    console.log(err);
  }


}
exports.sendRydeToken = sendRydeToken
