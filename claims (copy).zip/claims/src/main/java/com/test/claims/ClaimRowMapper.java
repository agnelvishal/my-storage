package com.test.claims;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.jdbc.core.RowMapper;

public class ClaimRowMapper implements RowMapper<Claim> {

	@Override
	public Claim mapRow(ResultSet rs, int rowNum) throws SQLException {
		Claim claim = new Claim();
		claim.setAuthor(rs.getString("author"));
		claim.setClaimNumber(rs.getString("claimnumber"));
		claim.setPdfName(rs.getString("pdfname"));
		claim.setTotalCost(rs.getLong("totalcost"));
		claim.setDate(rs.getDate("claimdate"));
		return claim;
	}

	
}
