package com.test.claims;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ClaimsController {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@RequestMapping(path = "/fetchClaims")
	public String fetchClaimDetails(@RequestParam String claimNo, Model model) {
		List<Claim> claimDetails = null;
		// populateDetails(claimDetails);
		Claim claim = getClaimDetails(claimNo);
		if (null != claim) {
			claimDetails = new ArrayList<Claim>();
			claimDetails.add(claim);
		}
		model.addAttribute("claimDetails", claimDetails);
		return "Claims";
	}

	/**
	 * Method to get claim details from database
	 * 
	 * @param claimNo
	 * @return
	 */
	public Claim getClaimDetails(String claimNo) {
		String sql = "SELECT * FROM PDF_File_OCR_Data WHERE claimNumber = ?";
		Claim result = (Claim) jdbcTemplate.queryForObject(sql, new Object[] { claimNo }, new ClaimRowMapper());
		return result;
	}

	/**
	 * Dummy method to populate attributes
	 * 
	 * @param claimDetails
	 */
	private void populateDetails(List<Claim> claimDetails) {
		Claim claim = new Claim();
		claim.setAuthor("testAuthor");
		claim.setClaimNumber("12346");
		claim.setPdfName("testDoc");
		claim.setTotalCost(123456l);
		claim.setDate(new Date());
		claimDetails.add(claim);
		Claim claim1 = new Claim();
		claim1.setAuthor("testAuthor1");
		claim1.setClaimNumber("12346");
		claim1.setPdfName("testDoc");
		claim1.setTotalCost(123456l);
		claim1.setDate(new Date());
		claimDetails.add(claim1);
	}

}
