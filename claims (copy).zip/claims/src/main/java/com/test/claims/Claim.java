package com.test.claims;

import java.util.Date;

public class Claim {
	
	private String claimNumber;
	
	private String pdfName;
	
	private String author;
	
	private Long totalCost;
	
	private Date date;
	
	public Claim() {
		
	}
	
	public Claim(String claimNumber, String pdfName, String author, Long totalCost, Date date) {
		super();
		this.claimNumber = claimNumber;
		this.pdfName = pdfName;
		this.author = author;
		this.totalCost = totalCost;
		this.date = date;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getPdfName() {
		return pdfName;
	}

	public void setPdfName(String pdfName) {
		this.pdfName = pdfName;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Long getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(Long totalCost) {
		this.totalCost = totalCost;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

		
	
}
